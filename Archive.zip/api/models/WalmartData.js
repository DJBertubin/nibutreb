const mongoose = require('mongoose');

const WalmartDataSchema = new mongoose.Schema({
    shopifySourceId: {
        type: String,
        required: true,
    },
    clientId: {
        type: String,
        required: true,
    },
    clientSecret: {
        type: String,
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('WalmartData', WalmartDataSchema);