import React, { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import ProductList from '../components/ProductList';
import MarketplaceDropdowns from '../components/MarketplaceDropdowns';
import ClientProfile from '../components/ClientProfile';
import IntegrationModal from '../components/IntegrationModal';

const AdminDashboard = () => {
    const [showIntegrationModal, setShowIntegrationModal] = useState(false);
    const [productData, setProductData] = useState([]);
    const [stores, setStores] = useState(['Walmart', 'Shopify']); // Initial stores list
    const [selectedStore, setSelectedStore] = useState('');
    const [clients, setClients] = useState([]); // Added for client management
    const [selectedClient, setSelectedClient] = useState(''); // Added for selecting a client

    useEffect(() => {
        // Fetch client list from API, replace 'api/clients' with your actual endpoint
        async function fetchClients() {
            const response = await fetch('/api/clients');
            const data = await response.json();
            setClients(data.clients);
        }
        fetchClients();
    }, []);

    const handleShowModal = () => {
        setShowIntegrationModal(true);
    };

    const handleCloseModal = () => {
        setShowIntegrationModal(false);
    };

    const handleShopifyConnect = (data) => {
        setProductData(data); // Update product data
    };

    const handleAddStoreName = (storeName) => {
        if (!stores.includes(storeName)) {
            setStores((prevStores) => [...prevStores, storeName]);
        }
        setSelectedStore(storeName); // Set the fetched store as selected
    };

    const handleClientChange = (e) => {
        setSelectedClient(e.target.value);
        // Additional logic to switch dashboard view can be added here
    };

    return (
        <div className="dashboard">
            <Sidebar userType="Admin" />
            <div className="main-content">
                <ClientProfile name="Jane Doe" clientId="98765" imageUrl="https://via.placeholder.com/100" />
                <select value={selectedClient} onChange={handleClientChange}>
                    {clients.map(client => (
                        <option key={client.id} value={client.id}>{client.name}</option>
                    ))}
                </select>
                <MarketplaceDropdowns
                    onAddNewSource={handleShowModal}
                    storeList={stores}
                    defaultSelectedStore={selectedStore} // Pass selected store as the default
                />
                <div className="content">
                    <h2 className="section-title">Products Overview</h2>
                    <div className="products-table">
                        <ProductList products={productData} />
                    </div>
                </div>
                {showIntegrationModal && (
                    <IntegrationModal
                        onClose={handleCloseModal}
                        onFetchSuccess={handleShopifyConnect}
                        onAddStoreName={handleAddStoreName}
                    />
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;
