import React, { useState, useEffect } from 'react';
import Sidebar from '../components/Sidebar';
import ClientProfile from '../components/ClientProfile';

const ClientDashboard = () => {
    const [productData, setProductData] = useState([]);
    const [loading, setLoading] = useState(true);

    // Fetch client's product data
    useEffect(() => {
        const fetchProducts = async () => {
            const token = localStorage.getItem('token');
            try {
                const response = await fetch('/api/client/products', {
                    headers: { Authorization: `Bearer ${token}` },
                });
                if (!response.ok) throw new Error('Failed to fetch products');
                const data = await response.json();
                setProductData(data);
            } catch (error) {
                console.error('Error fetching products:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchProducts();
    }, []);

    return (
        <div className="dashboard">
            <Sidebar userType="Client" />
            <div className="main-content">
                <ClientProfile name="John Doe" clientId="12345" imageUrl="https://via.placeholder.com/100" />
                <div className="content">
                    <h2 className="section-title">Your Products</h2>
                    {loading ? (
                        <p>Loading your products...</p>
                    ) : productData.length > 0 ? (
                        <ul className="product-list">
                            {productData.map((product) => (
                                <li key={product.id}>
                                    <strong>{product.name}</strong> - ${product.price.toFixed(2)}
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p>No products available.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ClientDashboard;
