import React from 'react';
import { useHistory } from 'react-router-dom';

function Logout({ setLoggedIn }) {
    const history = useHistory();

    const handleLogout = () => {
        fetch('/api/logout', {
            method: 'POST',
        }).then(() => {
            setLoggedIn(false);
            history.push('/login'); // Redirect to login page after logout
        });
    };

    return (
        <button onClick={handleLogout}>Logout</button>
    );
}

export default Logout;
